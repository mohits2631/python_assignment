boys={'nilesh':41,'soumitra':42,'nadeem':47}
girls={'rasika':38,'rajashree':43,'rasika':45}
combined={**boys,**girls}
print(combined)
combined={**girls,**boys}
print(combined)