#import module
import calendar
yy=2024
#display the calendar
print(calendar.calendar(yy))