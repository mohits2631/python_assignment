#mathematical function from math module
import math
x=1.5357
print(math.pi,math.e)
print(math.sqrt(x))
print(math.factorial(6))
print(math.fabs(x))
print(math.log(x))
print(math.log10(x))
print(math.exp(x))
print(math.trunc(x))
print(math.floor(x))
print(math.ceil(x))
print(math.trunc(-x))
print(math.floor(-x))
print(math.ceil(-x))
print(math.modf(x))

#Built-in mathematical functions
print(abs(-25))
print(pow(2,4))
print(min(10,20,30,40,50))
print(max(10,20,30,40,50))
print(divmod(17,3))
print(bin(64),oct(64),hex(64))
print(round(2.567), round(2.5678, 2))